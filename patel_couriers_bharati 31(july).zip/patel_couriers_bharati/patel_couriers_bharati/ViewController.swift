//
//  ViewController.swift
//  patel_couriers_bharati
//
//  Created by WindHans on 14/07/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

